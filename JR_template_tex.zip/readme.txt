V1.tex : multicols双栏，但是该环境不允许图片浮动

V2.tex : 双栏开头用multicols，页底用\twocolumn切换，同时换页。然后加\noindent续上第二页文字。